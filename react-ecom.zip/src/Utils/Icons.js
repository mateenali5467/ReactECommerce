const Icons = {
  GreenTick: <i className="fas fa-check text-default"></i>,
  RedCross: <i className="fas fa-times text-danger"></i>,
};

export default Icons;
