//test
// export const reCAPTCHA_SITE_KEY = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI";

//fordeployment
export const reCAPTCHA_SITE_KEY = "6LfVbtEcAAAAAONakP7JS8KApkmy-xTnGtfjPz5H";
////export const reCAPTCHA_SECRET_KEY = "6Ld0tNAcAAAAAK0JceDgUrbQ80_xml-QpzI5LUaY";

//test user email
//tjooqwsde@emltmp.com
