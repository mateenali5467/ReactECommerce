import Endpoint from "./../Utils/Endpoint";
import axios from "axios";
import BanglaBazarApi from "../Components/Api/BanglaBazarApi";
export async function CountryCodes2() {
  const response = await BanglaBazarApi.get(
    Endpoint + "/api/location/get-vendorAllowedCountries"
  );
  var array = [];
  var { Countries } = response.data;
  for (let i = 0; i < Countries.length; i++) {
    array.push(Countries[i]["ISO2"].toLowerCase());
  }
  return array;
}

export async function CountryCodes() {
  const response = await BanglaBazarApi.get(
    Endpoint + "/api/location/get-userAllowedCountries"
  );
  var array = [];
  var { Countries } = response.data;
  for (let i = 0; i < Countries.length; i++) {
    array.push(Countries[i]["ISO2"].toLowerCase());
  }
  return array;
}

export async function CountryNames() {
  const response = await BanglaBazarApi.get(
    Endpoint + "/api/location/get-userAllowedCountries"
  );
  var array = [];
  var { Countries } = response.data;
  for (let i = 0; i < Countries.length; i++) {
    array.push(Countries[i]["Country"].toLowerCase());
  }
  return array;
}
