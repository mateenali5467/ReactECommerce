import { createContext } from "react";
export const STORE_DETAIL_CONTEXT = createContext({});
