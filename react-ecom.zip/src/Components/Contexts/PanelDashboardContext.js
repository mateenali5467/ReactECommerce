import React from "react";
import { createContext } from "react";

export const PANEL_DASHBOARD_CONTEXT = createContext({});
