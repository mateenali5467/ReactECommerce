import { createContext } from "react";
const VendorRegistrationContext = createContext({});
export default VendorRegistrationContext;
