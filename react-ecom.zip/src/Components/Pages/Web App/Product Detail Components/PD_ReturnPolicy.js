import React from 'react'

const ProductReturnPolicy = ({ ReturnPolicy }) => {
    return (
        <div dangerouslySetInnerHTML={{ __html: ReturnPolicy }} />
    )
}

export default ProductReturnPolicy