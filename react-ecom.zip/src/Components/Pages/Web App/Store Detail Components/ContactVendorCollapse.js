import { useState } from "react";
import { Collapse } from "reactstrap";
import { useHistory } from "react-router-dom";

function ContactVendorCollapse({ Business }) {
  const history = useHistory();
  const [Open, setOpen] = useState(false);
  return (
    <>
      <div
        className="d-flex justify-content-between mt-3"
        //   onClick={() => setIsOpen(!isOpen)}
        style={{
          cursor: "pointer",
          borderBottom: "1px solid #C7C7C7",
        }}
        onClick={() => setOpen(!Open)}
      >
        <h6 className="ftw-400">Contact Vendor</h6>
        <div>
          {Open ? (
            <i className="fas fa-minus  text-secondary"></i>
          ) : (
            <i className="fas fa-plus text-secondary"></i>
          )}
        </div>
      </div>
      <Collapse isOpen={Open}>
        {/* <div className="row mt-2">
          <div className="col-6">
          <h6 >Email</h6>
          </div>
          <div className="col-6" style={{ wordWrap: "break-word" }}>
            {Business && Business.BusinessEmail}
          </div>
        </div>
        <div className="row mt-2">
          <div className="col-6">
            <h6 >Contact</h6>
          </div>
          <div className="col-6">{Business && Business.BusinessPhone}</div>
        </div> */}
        <div className="mt-2">
          <button
            onClick={() => {
              history.push(`/chat-support/${Business.VendorID}`);
            }}
            className="btn btn-default btn-lg"
          >
            Contact
          </button>
        </div>
      </Collapse>
    </>
  );
}
export default ContactVendorCollapse;
