import { useState } from "react";
import PhoneInput from "react-phone-input-2";
import ReactFlagsSelect from "react-flags-select";
import { useContext, useEffect } from "react";
import VendorRegistrationContext from "./../../../Contexts/VendorRegistrationContext";
import { BusinessPhoneVerificationModal } from "./BusinessPhoneVerificationModal";
import BusinessEmailVerificationModal from "./BusinessEmailVerificationModal";
import { Link } from "react-router-dom";
import { RequiredField } from "./../../../../Utils/Required-field";
import CreatableSelect from "react-select/creatable";
import firetoast from "./../../../../Helpers/FireToast";
import CheckEmpty from "./../../../../Utils/CheckEmpty";
import axios from "axios";
import Endpoint from "./../../../../Utils/Endpoint";
import { CountryCodes2 } from "../../../../Helpers/CountryCodes";
import BanglaBazarApi from "./../../../Api/BanglaBazarApi";
function SellStep3(props) {
  var {
    setBusinessEmailVerified,
    setBusinessPhoneVerified,
    setStoreName,
    StoreName,
    setStoreAddress1,
    setStoreAddress2,
    setStoreEmail,
    setStorePhone,
    setStoreFAX,
    setStoreURL,
    setActive,
    CountryList,
    StorePhone,
    StateList,
    StoreEmail,
    setStoreCountryID,
    setStoreState,
    setStoreCityID,
    CityID,
    setStoreCity,
    CityList,
    Active,
    StoreAddress2,
    StoreZipCode,
    setStoreZipCode,
    StorePhoneVerified,
    setStorePhoneVerified,
    StoreEmailVerified,
    StoreAddress1,
    setStoreEmailVerified,
    StoreCityID,
    StoreCity,
    StoreStateID,
    setStoreStateID,
    StoreState,
    StoreCountryID,
    StoreFAX,
    CountryID,
    StoreURL,
    BusinessEmail,
    StoreStateId,
    setStoreStateId,
    PathaoToken,
    zone_id,
    setZone_id,
    area_id,
    setArea_id,
    selectedVendorCountry,
    CountryCode,
    setPathaoCityID
  } = useContext(VendorRegistrationContext);
  const [phoneVerify, setPhoneVerify] = useState(false);
  const [emailModal, setEmailModal] = useState(false);
  let getStorageItems = localStorage.getItem("user");
  let userDetails = JSON.parse(getStorageItems);
  let verifiedPhone = localStorage.getItem("businessPhoneVerified");
  const userEmail = userDetails?.EmailAddress;
  const userPhoneNumber = verifiedPhone ? verifiedPhone : userDetails?.PhoneNumber;
  const userPhoneVerified = verifiedPhone ? "Y" : userDetails?.PhoneVerified;
  const userEmailVerified = userDetails?.EmailVerified;
  console.log(userPhoneVerified, "userPhoneNumber");

  const [emailChange, setEmailChange] = useState(false);
  const [selectedCity, setselectedCity] = useState(null);
  const [selectedState, setselectedState] = useState(null);
  // const [CountryCode, setCountryCode] = useState([]);
  const [StoreCityList, setStoreCityList] = useState(CityList);
  const [PathaoCities, setPathaoCities] = useState([]);
  const [ZoneList, setZoneList] = useState([]);
  const [AreaList, setAreaList] = useState([]);
  // const [PathaoCityID, setPathaoCityID] = useState(null)
  useEffect(async () => {
    if (userPhoneVerified === "Y") {
      setStorePhoneVerified(true);
    }
    if (userEmailVerified === "Y") {
      setStoreEmailVerified(true);
    }
    if (
      userPhoneNumber?.slice(0, 1) == "1" ||
      userPhoneNumber?.slice(0, 3) == "880"
    ) {
      setStorePhone(userPhoneNumber);
    } else {
      setBusinessPhoneVerified(false);
      setStorePhone(null);
    }
    // setCountryCode(await CountryCodes2());
    if (CountryID === 16) {
      getPathaoCities();
    }
  }, []);
  var getCitiesByState = async (id) => {
    try {
      var response = await BanglaBazarApi.get(
        Endpoint + `/api/location/get-cities/${id}`
      );
      setStoreCityList(response.data.Cities);
    } catch (e) {
      console.log(e);
    }
  };
  var getPathaoCities = async () => {
    var response = await BanglaBazarApi.post(
      Endpoint + "/api/pathao/get-pathao-cities",
      { token: PathaoToken }
    );
    setPathaoCities(response.data.cities);
  };
  var getZones = async (item) => {
    console.log(item);
    try {
      var response = await BanglaBazarApi.post(
        `${Endpoint}/api/pathao/get-pathao-zone`,
        {
          token: PathaoToken,
          city_id: item.PathaoCityID,
        }
      );
      setZoneList(response.data.zones);
    } catch (e) {
      console.log(e);
    }
  };
  var getAreas = async (item) => {
    try {
      var response = await BanglaBazarApi.post(
        `${Endpoint}/api/pathao/get-pathao-area`,
        {
          token: PathaoToken,
          zone_id: item.zone_id,
        }
      );
      setAreaList(response.data.areas);
    } catch (e) {
      console.log(e);
    }
  };
  // var createState = async (e) => {
  //   var { value, label } = e;
  //   if (CheckEmpty(CountryID)) {
  //     return firetoast(
  //       "Please Select Country first in order to create State",
  //       "error",
  //       3000,
  //       "top-right"
  //     );
  //   } else {
  //     var form = new URLSearchParams();

  //     form.append("CountryID", CountryID);
  //     form.append("StateName", label);
  //     var response = await axios.post(
  //       `${Endpoint}/api/location/add-newState`,
  //       form
  //     );
  //     return response.data.StateID;
  //   }
  // };
  // var createCity = async (e) => {
  //   var { value, label } = e;
  //   if (CheckEmpty(CountryID)) {
  //     return firetoast(
  //       "Please Select Country first in order to create city",
  //       "error",
  //       3000,
  //       "top-right"
  //     );
  //   }
  //   if (CheckEmpty(StateId)) {
  //     return firetoast(
  //       "Please Select State first in order to create city",
  //       "error",
  //       3000,
  //       "top-right"
  //     );
  //   }
  //   var form = new URLSearchParams();
  //   form.append("StateID", StateId);
  //   form.append("CountryID", CountryID);
  //   form.append("City", label);
  //   var response = await axios.post(
  //     `${Endpoint}/api/location/add-newCity`,
  //     form
  //   );
  //   return response.data.CityID;
  // };
  return (
    <>
      {/* {JSON.stringify(CityList)} */}
      <div className="mt-3">
        <h4 className="ftw-400">Store Info</h4>
        <div className="mb-5">
          <div className="row">
            {/* <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <input className="form-control" type="text" />
            </div> */}
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>
                Store Name <RequiredField />
              </label>
              <input
                className="form-control"
                defaultValue={StoreName}
                type="text"
                onChange={(e) => {
                  setStoreName(e.target.value);
                }}
              />
            </div>
          </div>
          <div className="row mt-4">
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>
                Store Email <RequiredField />
              </label>
              <input
                className="form-control"
                defaultValue={userEmail}
                type="email"
                onChange={(e) => {
                  if (userEmail === e.target.value) {
                    setStoreEmailVerified(true);
                    setEmailChange(false);
                    setStoreEmail(e.target.value);
                  } else {
                    setStoreEmailVerified(false);
                    setEmailChange(true);
                    setStoreEmail(e.target.value);
                  }
                }}
              />
              {console.log(BusinessEmail, "BusinessEmail")}
              {!StoreEmailVerified &&
                StoreEmail != userEmail &&
                emailChange && (
                  <>
                    <Link
                      to="#"
                      className="text-default mt-2"
                      onClick={() => setEmailModal(!emailModal)}
                      style={{ fontSize: "18px" }}
                    >
                      Verify your Email Address
                    </Link>{" "}
                  </>
                )}
            </div>
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>
                Store Phone <RequiredField />
              </label>

              <PhoneInput
                // countryCodeEditable={false}
                value={StorePhone}
                country={"bd"}
                onlyCountries={CountryCode}
                inputClass="adduser-phone"
                // isValid={(value, country) => {
                //   if (value.startsWith(country.countryCode)) {
                //     return true;
                //   } else {
                //     return false;
                //   }
                // }}
                onChange={(e) => {
                  if (e === userPhoneNumber) {
                    console.log("ok1");
                    setStorePhoneVerified(true);
                  } else {
                    console.log("ok2");
                    setStorePhoneVerified(false);
                  }
                  setStorePhone("+" + e);
                }}
              />

              {!StorePhoneVerified &&
                (userPhoneVerified != "Y" ||
                  (StorePhone && StorePhone != "+" + userPhoneNumber)) && (
                  <>
                    <Link
                      to="#"
                      className="text-default mt-2"
                      onClick={() => {
                        if (StorePhone.length > 6) {
                          setPhoneVerify(true);
                        }
                        else {
                          firetoast(
                            "Please Enter a Valid Phone Number.",
                            "error",
                            3000,
                            "top-right"
                          );
                        }
                      }}
                      style={{ fontSize: "18px" }}
                    >
                      Please Click here to verify your Business Phone first
                    </Link>{" "}
                  </>
                )}
              {/* <PhoneInput
                value={StorePhone}
                country={"bd"}
                onlyCountries={CountryCode}
                inputClass="adduser-phone"
                isValid={(value, country) => {
                  if (value.startsWith(country.countryCode)) {
                    return true;
                  } else {
                    return false;
                  }
                }}
                onChange={(e) => setStorePhone("+" + e)}
              /> */}
            </div>
          </div>
          <div className="row mt-4">
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>
                Address 1 <RequiredField />
              </label>
              <input
                className="form-control"
                type="text"
                defaultValue={StoreAddress1}
                onChange={(e) => setStoreAddress1(e.target.value)}
              />
            </div>
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>Address 2</label>
              <input
                className="form-control"
                type="text"
                defaultValue={StoreAddress2}
                onChange={(e) => setStoreAddress2(e.target.value)}
              />
            </div>
          </div>
          <div className="row mt-4">
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>
                Country <RequiredField />
              </label>
              <input
                className="form-control"
                value={selectedVendorCountry?.Country}
                disabled
              />
              {/* <select
                onChange={(e) => setStoreCountryID(e.target.value)}
                className="form-control"
              >
                <option>Select</option>
                {CountryList &&
                  CountryList.map((item, index) => (
                    <option
                      value={item.CountryID}
                      key={index}
                      disabled
                      selected={CountryID === item.CountryID}
                    >
                      {" "}
                      {item.Country}
                    </option>
                  ))}
              </select> */}
            </div>
          </div>
          {CountryID === 16 ? (
            <>
              <div className="row mt-4">
                <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
                  <label>
                    City <RequiredField />
                  </label>

                  <select
                    className="form-control"
                    onChange={(e) => {
                      if (e.target.value === "select") {
                        return e.preventDefault();
                      }
                      var item = JSON.parse(e.target.value);
                      setStoreCity(item.PathaoCityName);
                      setStoreCityID(item.DBCityID);
                      setPathaoCityID(item.PathaoCityID)
                      getZones(item);
                    }}
                  >
                    <option value="select">Select...</option>
                    {PathaoCities &&
                      PathaoCities.map((item, index) => (
                        <option value={JSON.stringify(item)} key={index}>
                          {item.PathaoCityName}
                        </option>
                      ))}
                  </select>
                  {/* {JSON.stringify(PathaoCities)} */}
                </div>
              </div>
              <div className="row mt-4">
                <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
                  <label>
                    Zones <RequiredField />
                  </label>

                  <select
                    className="form-control"
                    type="text"
                    placeholder="Enter City"
                    onChange={(e) => {
                      if (e.target.value === "select") {
                        return e.preventDefault();
                      }
                      var item = JSON.parse(e.target.value);
                      getAreas(item);
                      setZone_id(item.zone_id);
                    }}
                  >
                    <option value="select">Select Zone</option>
                    {ZoneList &&
                      ZoneList.map((item, index) => (
                        <option key={index} value={JSON.stringify(item)}>
                          {item.zone_name}
                        </option>
                      ))}
                  </select>
                </div>
                <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
                  <label>
                    Areas <RequiredField />
                  </label>

                  <select
                    className="form-control"
                    type="text"
                    placeholder="Enter City"
                    onChange={(e) => {
                      if (e.target.value === "select") {
                        return e.preventDefault();
                      }
                      var item = JSON.parse(e.target.value);
                      setArea_id(item.area_id);
                    }}
                  >
                    <option value="select">Select Areas</option>
                    {AreaList &&
                      AreaList.map((item, index) => (
                        <option key={index} value={JSON.stringify(item)}>
                          {item.area_name}
                        </option>
                      ))}
                  </select>
                </div>
                <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
                  <label>
                    ZipCode <RequiredField />
                  </label>
                  <input
                    className="form-control"
                    type="text"
                    value={StoreZipCode}
                    onChange={(e) => setStoreZipCode(e.target.value)}
                    placeholder="Enter Zipcode"
                  />
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="row mt-4">
                <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
                  <label>State / District /Province</label>
                  {/* <CreatableSelect
                isClearable
                onChange={(e) => {
                  if (e) {
                    if (e.__isNew__) {
                      setStoreState(e.label);
                    } else {
                      setStoreState(e.label);
                      // setStoreStateId(e.value);
                      // setselectedState(e);
                    }
                  } else {
                    setStoreState("");
                    // setStoreStateId("");
                    // setselectedState(null);
                  }
                }}
                // onInputChange={(e) => console.log(e)}
                options={StateList}
              /> */}
                  {StateList.length > 0 ? (
                    <select
                      className="form-control"
                      onChange={(e) => {
                        setStoreState(JSON.parse(e.target.value).State);
                        getCitiesByState(JSON.parse(e.target.value).StateID);
                      }}
                    >
                      <option>Select...</option>
                      {StateList &&
                        StateList.map((item, index) => (
                          <option
                            value={JSON.stringify(item)}
                            key={index}
                            selected={StoreState === item.State}
                          >
                            {item.State}
                          </option>
                        ))}
                    </select>
                  ) : (
                    <input
                      className="form-control"
                      defaultValue={StoreState}
                      onChange={(e) => setStoreState(e.target.value)}
                    />
                  )}
                </div>
              </div>
              <div className="row mt-4">
                <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
                  <label>City <RequiredField /></label>

                  {/* <CreatableSelect
                isClearable
                onChange={(e) => {
                  if (e) {
                    if (e.__isNew__) {
                      setStoreCity(e.label);
                    } else {
                      setStoreCity(e.label);
                      setStoreCityID(e.value);
                      // setselectedCity(e);
                    }
                  } else {
                    setStoreCity("");
                    setStoreCityID("");
                    // setselectedCity(null);
                  }
                }}
                // onInputChange={(e) => console.log(e)}
                options={CityList}
              /> */}
                  {StoreCityList.length > 0 ? (
                    <select
                      className="form-control"
                      type="text"
                      placeholder="Enter City"
                      onChange={(e) => {
                        var item = JSON.parse(e.target.value);
                        setStoreCity(item.City);
                        setStoreCityID(item.CityID);
                      }}
                    >
                      <option>Select City </option>
                      {StoreCityList &&
                        StoreCityList.map((item, index) => (
                          <option
                            key={index}
                            value={JSON.stringify(item)}
                            selected={StoreCity === item.City}
                          >
                            {item.City}
                          </option>
                        ))}
                    </select>
                  ) : (
                    <input
                      className="form-control"
                      defaultValue={StoreCity}
                      onChange={(e) => setStoreCity(e.target.value)}
                    />
                  )}
                </div>
                <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
                  <label>ZipCode <RequiredField /></label>
                  <input
                    className="form-control"
                    type="text"
                    value={StoreZipCode}
                    onChange={(e) => setStoreZipCode(e.target.value)}
                    placeholder="Enter Zipcode"
                  />
                </div>
              </div>
            </>
          )}

          <div className="row mt-4">
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>
                Store Fax <small>(optional)</small>
              </label>
              <input
                className="form-control"
                type="text"
                placeholder="Enter Store Fax"
                defaultValue={StoreFAX}
                onChange={(e) => setStoreFAX(e.target.value)}
              />
            </div>
            <div className="col-lg-6 col-xl-6 col-md-6 col-sm-12 col-xs-12">
              <label>
                Store URL <small>(optional)</small>
              </label>
              <input
                className="form-control"
                type="text"
                defaultValue={StoreURL}
                onChange={(e) => setStoreURL(e.target.value)}
              />
            </div>
          </div>
          {/* <div className="row mt-4">
            <div className="col-lg-12 col-xl-12 col-md-12 col-sm-12 col-xs-12">
              <label>Active</label>
              <div className="d-flex" style={{ alignItems: "end" }}>
                <div className="cs-bi-radios">
                  <label>
                    <input
                      type="radio"
                      className="cs-bi-radios-input"
                      name="active"
                      defaultChecked={Active === "Y"}
                      onChange={() => setActive("Y")}
                    />{" "}
                    Yes
                  </label>
                </div>
                <div className="cs-bi-radios">
                  <label>
                    <input
                      type="radio"
                      className="cs-bi-radios-input"
                      name="active"
                      defaultChecked={Active === "N"}
                      onChange={() => setActive("N")}
                    />{" "}
                    No
                  </label>
                </div>
              </div>
            </div>
          </div> */}
          {/* <div className="row mt-4">
            <div className="col-lg-12 col-xl-12 col-md-12 col-sm-12 col-xs-12">
              <label>Admin Note</label>
              <textarea className="form-control" rows={"5"} />
            </div>
          </div> */}
          <BusinessPhoneVerificationModal
            phoneVerify={phoneVerify}
            setPhoneVerify={setPhoneVerify}
            phoneToBeVerified={StorePhone}
            setPhoneStatus={setStorePhoneVerified}
          />
          <BusinessEmailVerificationModal
            emailVerify={emailModal}
            setEmailVerify={setEmailModal}
            setEmailVerified={setStoreEmailVerified}
            status="2"
          />
        </div>
      </div>
    </>
  );
}
export default SellStep3;
