import React, { useState } from 'react';
import { RequiredField } from '../../../../../Utils/Required-field';

const VariationInput = ({ variation, editeAble, onValueChange }) => {

    const handleChange = (e) => {
        onValueChange(e.target.value);
    };

    return (
        <div className="col-6">
            <label>{variation.VariantName} <RequiredField /></label>
            <input
                disabled={editeAble}
                className="form-control"
                type="text"
                name="VariantValue"
                onChange={handleChange}
            // value={}
            />
        </div>
    );
}

export default VariationInput;
